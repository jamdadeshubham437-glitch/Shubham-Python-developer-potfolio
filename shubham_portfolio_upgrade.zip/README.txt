# Shubham Jamdade — Portfolio

## Files
- `index.html` — page content
- `style.css` — responsive styling
- `script.js` — mobile navigation

## Update your GitHub Pages website
1. Open your GitHub repository: `Shubham-Python-developer-portfolio`.
2. Choose **Add file → Upload files**.
3. Upload these three files from this folder and choose **Commit changes**.
4. GitHub Pages should automatically rebuild the site from `main` / `(root)`.
5. Refresh your live portfolio after the deployment completes.

## Before sharing with recruiters
- Verify the LinkedIn URL in `index.html` is your correct profile.
- Check that the project description and skills accurately reflect what you built and can explain.
- Add a PDF CV only when you have a current, accurate version. The current page intentionally avoids a fake CV download.
